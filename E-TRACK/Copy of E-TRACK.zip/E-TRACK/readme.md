1st user need to create a db name E-TRACK

2nd import the sql file from the folder ,the file name is e-track,import the e-track file in your db E-TRACk

3rd move your E-TRACK folder to htdocs folder ,u can find your htdoc folder in C:\xampp\htdocs this is the path for htdocs in nside this folder you need to paste your E-TRACK folder 

4th after doing all the things open xampp server and on apache and mysql,then in url search for http://localhost/E-TRACK/login
    it will directly redirect to your website E-TRACK